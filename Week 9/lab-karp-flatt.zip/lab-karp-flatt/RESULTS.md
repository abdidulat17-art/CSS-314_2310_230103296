# Karp–Flatt Practice Lab — Results

**Hardware (where these numbers were measured):** Intel Xeon @ 2.10 GHz, **2 vCPUs** (no SMT), Linux 6.18, CPython 3.13. This was a 2-core sandbox, so **P=4 is oversubscribed** (4 processes on 2 cores). Re-run the three scripts on your own machine and replace the table before submitting.

| Experiment | Mode | T1 (s) | T2 (s) | T4 (s) | e(2) | e(4) | Architectural Diagnosis |
|---|---|---|---|---|---|---|---|
| A | Serial Tail | 3.388 | 1.853 | 1.921 | 0.094 | 0.422 | e(2) ≈ 0.09 matches the sleep-based serial fraction; e(4) rises only because P=4 exceeds the 2 available cores |
| B | Lock Contention | 0.648 | 5.842 | 2.915 | 17.020 | 5.660 | Negative speedup (Sp = 0.11 and 0.22): mutex and cache-line thrashing |
| C | Privatized State | 0.401 | 0.250 | 0.245 | 0.247 | 0.480 | Scaling restored up to the core count (E2 = 80%); flat beyond 2 cores because only 2 exist |

## Rubric checks on this run

- **A:** e(4)/e(2) = 4.50, outside [0.80, 1.25]. Not met here; caused by running P=4 on 2 cores, expected to pass on ≥4 cores.
- **B:** T4 > T1 holds (2.915 s vs 0.648 s). e(4) >> e(2) does not hold here (5.66 < 17.02): on 2 cores the P=2 run is the true cross-core contention case, and the P=4 run partly serializes through time slicing. Expected to pass on ≥4 cores.
- **C:** T4 < T1 holds, but E4 = 41% (< 70%) because only 2 cores exist; E2 = 80%.

## Notes

- Karp–Flatt: e(p) = (p·Tp/T1 − 1)/(p − 1).
- Experiment A's serial fraction here is about 0.40/3.39 ≈ 12% of T1, consistent with e(2) ≈ 0.09.
